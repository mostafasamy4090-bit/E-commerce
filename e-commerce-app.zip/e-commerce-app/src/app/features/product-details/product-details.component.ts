import { Component, inject, OnInit, signal, WritableSignal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { ProductsService } from '../../core/services/products/products.service';
import { IProduct } from '../../core/models/IProduct/iproduct.interface';
import { CurrencyPipe } from '@angular/common';
import { CartService } from '../../core/services/cart/cart.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-product-details',
  imports: [RouterLink, CurrencyPipe],
  templateUrl: './product-details.component.html',
  styleUrl: './product-details.component.css',
})
export class ProductDetailsComponent implements OnInit {
  private readonly activatedRoute = inject(ActivatedRoute);
  private readonly productsService = inject(ProductsService);
  private readonly cartService = inject(CartService);
  private readonly toastr = inject(ToastrService);

  activeTab: string = 'details';
  productId: WritableSignal<string | null> = signal('');
  prodData: WritableSignal<IProduct> = signal({} as IProduct);
  setTab(tabName: string): void {
    this.activeTab = tabName;
  }

  ngOnInit(): void {
    this.getProductIdFromRout();
  }

  getProductIdFromRout() {
    this.activatedRoute.paramMap.subscribe((url) => {
      if (url.get('id')) {
        this.productId.set(url.get('id'));
        this.getSpecificProduct();
      }
    });
  }

  getSpecificProduct() {
    this.productsService.getSpecificProduct(this.productId()).subscribe({
      next: (res) => {
        console.log(res);
        this.prodData.set(res.data);
      },
      error: (err) => {
        console.log(err);
      },
    });
  }

  addProductToCart(id: string) {
    this.cartService.addProductToCart(id).subscribe({
      next: (res) => {
        this.toastr.success(res.message, 'Fresh Cart');
        this.cartService.numberOfCartItems.set(res.numOfCartItems);
      },
      error: (err) => {
        this.toastr.error(err.message, 'Fresh Cart');
      },
    });
  }
}
