import {
  Component,
  computed,
  inject,
  OnInit,
  PLATFORM_ID,
  Signal,
  signal,
  effect,
} from '@angular/core';
import { Router, RouterLink, RouterLinkActive, NavigationEnd } from '@angular/router';
import { CartService } from '../../core/services/cart/cart.service';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import { AuthService } from '../../core/services/auth/auth.service';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive, CommonModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css',
})
export class NavbarComponent implements OnInit {
  private readonly cartService = inject(CartService);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);

  mobileMenuOpen = signal(false);
  userMenuOpen = signal(false);

  cartItem = computed(() => this.cartService.numberOfCartItems());
  isLoggedIn = computed(() => this.authService.isLoggedIn());

  constructor() {
    effect(() => {
      if (this.isLoggedIn() && isPlatformBrowser(this.platformId)) {
        this.getLoggedUserCart();
      }
    });
  }

  ngOnInit(): void {
    this.router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe(() => {
      this.mobileMenuOpen.set(false);
      this.userMenuOpen.set(false);
    });
  }

  toggleUserMenu() {
    this.userMenuOpen.update((val) => !val);
  }

  toggleMenu() {
    this.mobileMenuOpen.update((val) => !val);
  }

  getLoggedUserCart() {
    this.cartService.getLoggedUserCart().subscribe({
      next: (res) => {
        this.cartService.numberOfCartItems.set(res.numOfCartItems);
      },
      error: (err) => console.error('Cart Error:', err),
    });
  }

  logout() {
    this.authService.logout();
    this.userMenuOpen.set(false);
    this.mobileMenuOpen.set(false);
  }
}
