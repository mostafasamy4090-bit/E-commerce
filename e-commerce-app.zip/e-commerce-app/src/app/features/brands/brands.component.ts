import { Component, inject, OnInit, signal, WritableSignal } from '@angular/core';
import { BrandsService } from '../../core/services/brands/brands.service';
import { IBrand } from '../../core/models/IBrand/ibrand.interface';
import { NgxPaginationModule } from 'ngx-pagination';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-brands',
  imports: [NgxPaginationModule, RouterLink],
  templateUrl: './brands.component.html',
  styleUrl: './brands.component.css',
})
export class BrandsComponent implements OnInit {
  private readonly brandsService = inject(BrandsService);

  brandList: WritableSignal<IBrand[]> = signal([]);
  pageSize: WritableSignal<number> = signal(0);
  total: WritableSignal<number> = signal(0);
  currentPage: WritableSignal<number> = signal(1);

  ngOnInit(): void {
    this.getAllBrands();
  }

  getAllBrands(pageNumber: number = 1) {
    this.brandsService.getAllBrands(pageNumber).subscribe({
      next: (res) => {
        this.brandList.set(res.data);
        this.pageSize.set(res.metadata.limit);
        this.total.set(res.metadata.total);
        this.currentPage.set(res.metadata.page);
      },
      error: (err) => {
        console.error('Error fetching brands:', err);
      },
    });
  }

  pagedChanged(e: any) {
    this.currentPage.set(e);
    this.getAllBrands(e);
  }
}
