import { Component, inject, OnInit, signal, PLATFORM_ID } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CartService } from '../../core/services/cart/cart.service';
import { ICart } from '../../core/models/ICart/icart.interface';
import { CurrencyPipe, isPlatformBrowser } from '@angular/common';
import { AuthService } from '../../core/services/auth/auth.service';

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [RouterLink, CurrencyPipe],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css',
})
export class CartComponent implements OnInit {
  private readonly cartService = inject(CartService);
  private readonly authService = inject(AuthService);
  private readonly platformId = inject(PLATFORM_ID);

  cartDetails = signal<ICart | null>(null);

  isLoggedIn = this.authService.isLoggedIn;

  ngOnInit(): void {
    if (this.isLoggedIn()) {
      this.getLoggedUserCart();
    }
  }

  getLoggedUserCart(): void {
    this.cartService.getLoggedUserCart().subscribe({
      next: (res) => {
        this.cartDetails.set(res);
      },
      error: (err) => console.error('Error fetching cart:', err),
    });
  }

  deleteCartItem(id: string): void {
    this.cartService.removeItemFromCart(id).subscribe({
      next: (res) => {
        // لاحظ: لم نعد بحاجة لتحديث numberOfCartItems يدوياً هنا
        // لأن الـ CartService يقوم بذلك الآن تلقائياً
        this.cartDetails.set(res);
      },
      error: (err) => console.error('Error removing item:', err),
    });
  }

  clearCart(): void {
    this.cartService.clearCart().subscribe({
      next: (res) => {
        if (res.message === 'success') {
          // تصفير البيانات محلياً
          this.cartDetails.set(null);
        }
      },
      error: (err) => console.error('Error clearing cart:', err),
    });
  }

  updateQTY(id: string, count: number): void {
    if (count < 1) return;

    this.cartService.updateItemQTY(id, count).subscribe({
      next: (res) => {
        this.cartDetails.set(res);
      },
      error: (err) => console.error('Error updating quantity:', err),
    });
  }
}
