import {
  Component,
  CUSTOM_ELEMENTS_SCHEMA,
  inject,
  OnInit,
  signal,
  WritableSignal,
} from '@angular/core';
import { ProductCardComponent } from '../../shared/components/product-card/product-card.component';
import { ProductsService } from '../../core/services/products/products.service';
import { IProduct } from '../../core/models/IProduct/iproduct.interface';
import { CategoryCardComponent } from '../../shared/components/category-card/category-card.component';
import { CategoriesService } from '../../core/services/categories/categories.service';
import { ICategory } from '../../core/models/ICategory/icategory.interface';
import { RouterLink } from '@angular/router';
import { register } from 'swiper/element/bundle';

@Component({
  selector: 'app-home',
  imports: [ProductCardComponent, CategoryCardComponent, RouterLink],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent implements OnInit {
  private readonly productsService = inject(ProductsService);
  private readonly categoriesService = inject(CategoriesService);
  productList: WritableSignal<IProduct[]> = signal([]);
  categoryList: WritableSignal<ICategory[]> = signal([]);

  ngOnInit(): void {
    this.getAllProducts();
    this.getAllCategories();
    register();
  }

  getAllProducts() {
    this.productsService.getAllProducts().subscribe({
      next: (res) => {
        this.productList.set(res.data);
      },
      error: (err) => {
        console.log(err);
      },
    });
  }

  getAllCategories() {
    this.categoriesService.getAllCategories().subscribe({
      next: (res) => {
        this.categoryList.set(res.data);
      },
      error: (err) => {
        console.log(err);
      },
    });
  }
}
