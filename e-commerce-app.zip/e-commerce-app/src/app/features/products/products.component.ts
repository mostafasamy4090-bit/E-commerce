import { Component, inject, OnInit, signal, WritableSignal } from '@angular/core';
import { RouterLink, ActivatedRoute } from '@angular/router';
import { ProductCardComponent } from '../../shared/components/product-card/product-card.component';
import { IProduct } from '../../core/models/IProduct/iproduct.interface';
import { ProductsService } from '../../core/services/products/products.service';
import { NgxPaginationModule } from 'ngx-pagination';

@Component({
  selector: 'app-products',
  imports: [RouterLink, ProductCardComponent, NgxPaginationModule],
  templateUrl: './products.component.html',
  styleUrl: './products.component.css',
})
export class ProductsComponent implements OnInit {
  private readonly productsService = inject(ProductsService);
  private readonly activatedRoute = inject(ActivatedRoute);
  productList: WritableSignal<IProduct[]> = signal([]);

  pageSize: WritableSignal<number> = signal(0);
  total: WritableSignal<number> = signal(0);
  currentPage: WritableSignal<number> = signal(1);
  currentBrandId: string | null = null;

  ngOnInit(): void {
    this.activatedRoute.queryParamMap.subscribe({
      next: (params) => {
        this.currentBrandId = params.get('brandId');
        this.getAllProducts(1);
      },
    });
  }

  getAllProducts(pageNumber: number = 1): void {
    this.productsService.getAllProducts(pageNumber, this.currentBrandId || undefined).subscribe({
      next: (res) => {
        this.productList.set(res.data);
        this.pageSize.set(res.metadata.limit);
        this.total.set(res.metadata.total);
        this.currentPage.set(res.metadata.page);
      },
      error: (err) => {
        console.error('Error fetching products:', err);
      },
    });
  }

  pagedChanged(e: any) {
    this.currentPage.set(e);
    this.getAllProducts(e);
  }
}
