import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CartService } from '../../core/services/cart/cart.service';
import { ICart } from '../../core/models/ICart/icart.interface';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css',
})
export class CheckoutComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly activatedRoute = inject(ActivatedRoute);
  private readonly cartService = inject(CartService);
  private readonly router = inject(Router);

  checkoutForm!: FormGroup;
  cartId = signal<string | null>(null);
  cartDetails = signal<ICart | null>(null);
  isLoading = signal<boolean>(false);
  selectedPayment = signal<'online' | 'cash'>('online');

  ngOnInit(): void {
    this.initForm();
    this.getCartIdFromUrl();
    this.getCartDetails();
  }

  private initForm(): void {
    this.checkoutForm = this.fb.group({
      details: [null, [Validators.required, Validators.minLength(5)]],
      phone: [null, [Validators.required, Validators.pattern(/^01[0125][0-9]{8}$/)]],
      city: [null, [Validators.required]],
    });
  }

  private getCartIdFromUrl(): void {
    this.activatedRoute.paramMap.subscribe((params) => {
      this.cartId.set(params.get('cartId'));
    });
  }

  getCartDetails(): void {
    this.cartService.getLoggedUserCart().subscribe({
      next: (res) => this.cartDetails.set(res),
      error: (err) => console.error('Error fetching cart:', err),
    });
  }

  handlePayment(): void {
    if (this.checkoutForm.invalid) {
      this.checkoutForm.markAllAsTouched();
      return;
    }

    this.isLoading.set(true);
    const shippingAddress = this.checkoutForm.value;

    if (this.selectedPayment() === 'online') {
      this.payOnline(shippingAddress);
    } else {
      this.payCash(shippingAddress);
    }
  }

  private payOnline(address: any): void {
    this.cartService.checkoutSession(this.cartId()!, address).subscribe({
      next: (res) => {
        if (res.status === 'success') {
          localStorage.setItem('pendingCartId', this.cartId()!);
          window.location.href = res.session.url;
        }
      },
      error: (err) => this.stopLoading(err),
    });
  }

  private payCash(address: any): void {
    this.cartService.createCashOrder(this.cartId()!, address).subscribe({
      next: (res) => {
        if (res.status === 'success') {
          this.router.navigate(['/allorders']);
        }
      },
      error: (err) => this.stopLoading(err),
    });
  }

  private stopLoading(err: any): void {
    console.error('Checkout Error:', err);
    this.isLoading.set(false);
  }
}
