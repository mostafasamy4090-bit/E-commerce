import { Component, inject, OnInit, signal, WritableSignal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth/auth.service';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-forgot-password',
  imports: [RouterLink, ReactiveFormsModule, CommonModule],
  templateUrl: './forgot-password.component.html',
  styleUrl: './forgot-password.component.css',
})
export class ForgotPasswordComponent implements OnInit {
  private readonly authService = inject(AuthService);
  private readonly fb = inject(FormBuilder);
  private readonly router = inject(Router);

  forgotPasswordSuccessMessage: WritableSignal<string> = signal('');
  forgotPasswordErrorMessage: WritableSignal<string> = signal('');
  verifyResetCodeSuccessMessage: WritableSignal<string> = signal('');
  verifyResetCodeErrorMessage: WritableSignal<string> = signal('');
  resetPasswordSuccessMessage: WritableSignal<string> = signal('');
  resetPasswordErrorMessage: WritableSignal<string> = signal('');

  stepNumber: WritableSignal<number> = signal(1);

  forgotPasswordForm!: FormGroup;
  verifyResetCodeForm!: FormGroup;
  resetPasswordForm!: FormGroup;

  ngOnInit(): void {
    this.initForm();
  }

  initForm() {
    this.forgotPasswordForm = this.fb.group({
      email: [null, [Validators.required, Validators.email]],
    });

    this.verifyResetCodeForm = this.fb.group({
      resetCode: [null, [Validators.required]],
    });

    this.resetPasswordForm = this.fb.group({
      email: [null, [Validators.required, Validators.email]],
      newPassword: [
        null,
        [
          Validators.required,
          Validators.minLength(8),
          Validators.maxLength(20),
          Validators.pattern(
            /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&^#()\[\]{}\-_=+|;:'",.<>\/\\]).{8,}$/,
          ),
        ],
      ],
    });
  }

  forgotPassword() {
    this.authService.forgotPassword(this.forgotPasswordForm.value).subscribe({
      next: (res) => {
        this.forgotPasswordSuccessMessage.set(`${res.message} reset password successfully`);
        this.forgotPasswordErrorMessage.set('');
        this.stepNumber.set(2);
      },
      error: (err) => {
        this.forgotPasswordErrorMessage.set(err.error.message);
        this.forgotPasswordSuccessMessage.set('');
      },
    });
  }

  verifyResetCode() {
    this.authService.forgotPassword(this.verifyResetCodeForm.value).subscribe({
      next: (res) => {
        this.resetPasswordSuccessMessage.set(`${res.message} reset password successfully`);
        this.resetPasswordErrorMessage.set('');
        this.stepNumber.set(3);
      },
      error: (err) => {
        this.resetPasswordErrorMessage.set(err.error.message);
        this.resetPasswordSuccessMessage.set('');
      },
    });
  }

  resetPassword() {
    this.authService.resetPassword(this.resetPasswordForm.value).subscribe({
      next: (res) => {
        this.resetPasswordSuccessMessage.set(`${res.message} reset password successfully`);
        this.resetPasswordErrorMessage.set('');
        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 2000);
      },
      error: (err) => {
        this.resetPasswordErrorMessage.set(err.error.message);
        this.resetPasswordSuccessMessage.set('');
      },
    });
  }
}
