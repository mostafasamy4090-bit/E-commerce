import { Component, inject, input, InputSignal } from '@angular/core';
import { IProduct } from '../../../core/models/IProduct/iproduct.interface';
import { CurrencyPipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { CartService } from '../../../core/services/cart/cart.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-product-card',
  imports: [CurrencyPipe, RouterLink],
  templateUrl: './product-card.component.html',
  styleUrl: './product-card.component.css',
})
export class ProductCardComponent {
  data: InputSignal<IProduct> = input.required<IProduct>();
  private readonly cartService = inject(CartService);
  private readonly toastr = inject(ToastrService);

  addProductToCart(id: string) {
    this.cartService.addProductToCart(id).subscribe({
      next: (res) => {
        this.toastr.success(res.message, 'Fresh Cart');
        this.cartService.numberOfCartItems.set(res.numOfCartItems);
      },
      error: (err) => {
        this.toastr.error(err.message, 'Fresh Cart');
      },
    });
  }
}
