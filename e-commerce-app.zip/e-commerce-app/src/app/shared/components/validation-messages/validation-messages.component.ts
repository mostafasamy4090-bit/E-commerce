import { Component, inject, Input } from '@angular/core';
import { FormGroupDirective } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ValidationMessages } from '../../validation/validation-messages';

@Component({
  selector: 'app-validation-messages',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './validation-messages.component.html',
  styleUrl: './validation-messages.component.css',
})
export class ValidationMessagesComponent {
  @Input() controlName!: string;

  private form = inject(FormGroupDirective, { optional: true });

  get errors(): string[] {
    const control = this.form?.control?.get(this.controlName);

    if (!control || !control.errors || !(control.dirty || control.touched)) return [];

    return Object.keys(control.errors)
      .map((key) => {
        if (key === 'pattern') {
          if (this.controlName === 'password') return ValidationMessages['passwordPattern']();
          if (this.controlName === 'phone') return ValidationMessages['phonePattern']();
        }

        return ValidationMessages[key]?.(control.errors?.[key]);
      })
      .filter(Boolean);
  }
}
