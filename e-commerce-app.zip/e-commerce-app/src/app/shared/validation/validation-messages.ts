export const ValidationMessages: any = {
  required: () => 'This field is required',

  minlength: (e: any) => `Minimum ${e.requiredLength} characters`,

  maxlength: (e: any) => `Maximum ${e.requiredLength} characters`,

  email: () => 'Enter valid email',

  passwordPattern: () => 'Must contain uppercase, lowercase, number and special character',

  phonePattern: () => 'Enter a valid Egyptian phone number (010, 011, 012, 015)',

  mismatch: () => 'Passwords do not match',
};
