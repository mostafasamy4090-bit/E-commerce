import { Routes } from '@angular/router';
import { NotFoundComponent } from './features/not-found/not-found.component';
import { HomeComponent } from './features/home/home.component';
import { ProductsComponent } from './features/products/products.component';
import { ProductDetailsComponent } from './features/product-details/product-details.component';
import { BrandsComponent } from './features/brands/brands.component';
import { CategoriesComponent } from './features/categories/categories.component';
import { SupportComponent } from './features/support/support.component';
import { WishlistComponent } from './features/wishlist/wishlist.component';
import { LoginComponent } from './core/auth/login/login.component';
import { RegisterComponent } from './core/auth/register/register.component';
import { ForgotPasswordComponent } from './features/forgot-password/forgot-password.component';
import { CartComponent } from './features/cart/cart.component';
import { CheckoutComponent } from './features/checkout/checkout.component';
import { AllordersComponent } from './features/allorders/allorders.component';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'login', component: LoginComponent, title: 'Fresh Cart | Login' },
  { path: 'register', component: RegisterComponent, title: 'Fresh Cart | Register' },

  { path: 'home', component: HomeComponent, title: 'Fresh Cart | Home' },
  { path: 'products', component: ProductsComponent, title: 'Fresh Cart | Products' },
  {
    path: 'product-details/:id',
    component: ProductDetailsComponent,
    title: 'Fresh Cart | Products Details',
  },
  { path: 'brands', component: BrandsComponent, title: 'Fresh Cart | Brands' },
  { path: 'categories', component: CategoriesComponent, title: 'Fresh Cart | Categories' },
  { path: 'support', component: SupportComponent, title: 'Fresh Cart | Support' },
  { path: 'wishlist', component: WishlistComponent, title: 'Fresh Cart | Wishlist' },
  { path: 'cart', component: CartComponent, title: 'Fresh Cart | Cart' },
  { path: 'allorders', component: AllordersComponent, title: 'Fresh Cart | All Orders' },
  { path: 'checkout/:cartId', component: CheckoutComponent, title: 'Fresh Cart | Checkout' },

  {
    path: 'forgot-password',
    component: ForgotPasswordComponent,
    title: 'Fresh Cart | Forgot Password',
  },

  { path: '**', component: NotFoundComponent, title: 'Fresh Cart | Not Found' },
];
