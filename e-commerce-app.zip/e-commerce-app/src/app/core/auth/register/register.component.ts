import { Component, inject, OnInit, signal, WritableSignal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ValidationMessagesComponent } from '../../../shared/components/validation-messages/validation-messages.component';
import { AuthService } from '../../services/auth/auth.service';

@Component({
  selector: 'app-register',
  imports: [RouterLink, ReactiveFormsModule, ValidationMessagesComponent],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css',
})
export class RegisterComponent implements OnInit {
  private readonly fb = inject(FormBuilder);
  private readonly authService = inject(AuthService);
  private readonly router = inject(Router);

  errorMessage: WritableSignal<string> = signal('');
  successMessage: WritableSignal<string> = signal('');

  registerForm!: FormGroup;

  ngOnInit(): void {
    this.formInit();
  }

  register() {
    if (this.registerForm.valid) {
      this.authService.signUp(this.registerForm.value).subscribe({
        next: (res) => {
          console.log(res);

          this.successMessage.set(`${res.message} account created successfully`);
          this.errorMessage.set('');
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 2000);
        },
        error: (err) => {
          console.log(err);

          this.errorMessage.set(err.error.message);
          this.successMessage.set('');
        },
      });
    }
  }

  formInit() {
    this.registerForm = this.fb.group({
      name: [null, [Validators.required, Validators.minLength(3), Validators.maxLength(20)]],
      email: [null, [Validators.required, Validators.email]],
      password: [
        null,
        [
          Validators.required,
          Validators.minLength(6),
          Validators.maxLength(20),
          Validators.pattern(
            /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&^#()\[\]{}\-_=+|;:'",.<>\/\\]).{8,}$/,
          ),
        ],
      ],
      rePassword: [null, [Validators.required]],
      phone: [
        null,
        [
          Validators.required,
          Validators.minLength(11),
          Validators.maxLength(11),
          Validators.pattern(/^01[0125][0-9]{8}$/),
        ],
      ],
    });
  }
}
