import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class BrandsService {
  private readonly http = inject(HttpClient);

  getAllBrands(pageNumber: any = 1): Observable<any> {
    return this.http.get(`${environment.baseURL}/api/v1/brands`, {
      params: {
        page: pageNumber,
      },
    });
  }
}
