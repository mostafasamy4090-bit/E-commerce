import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class ProductsService {
  private readonly http = inject(HttpClient);
  getAllProducts(pageNumber: any = 1, brandId?: string): Observable<any> {
    let queryParams: any = {
      page: pageNumber,
    };

    if (brandId) {
      queryParams.brand = brandId;
    }

    return this.http.get(`${environment.baseURL}/api/v1/products`, {
      params: queryParams,
    });
  }
  getSpecificProduct(id: string | null): Observable<any> {
    return this.http.get(`${environment.baseURL}/api/v1/products/${id}`);
  }
}
