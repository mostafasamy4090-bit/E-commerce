import { HttpClient } from '@angular/common/http';
import { inject, Injectable, signal, PLATFORM_ID } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { isPlatformBrowser } from '@angular/common';
import { environment } from '../../../../environments/environment.development';

@Injectable({
  providedIn: 'root',
})
export class CartService {
  private readonly httpClient = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);

  numberOfCartItems = signal<number>(0);

  addProductToCart(prodId: string): Observable<any> {
    return this.httpClient
      .post<any>(`${environment.baseURL}/api/v1/cart`, {
        productId: prodId,
      })
      .pipe(
        tap((res) => {
          if (res.status === 'success') {
            this.numberOfCartItems.set(res.numOfCartItems);
          }
        }),
      );
  }

  getLoggedUserCart(): Observable<any> {
    return this.httpClient.get<any>(`${environment.baseURL}/api/v1/cart`).pipe(
      tap((res) => {
        this.numberOfCartItems.set(res.numOfCartItems || 0);
      }),
    );
  }

  removeItemFromCart(itemId: string): Observable<any> {
    return this.httpClient.delete<any>(`${environment.baseURL}/api/v1/cart/${itemId}`).pipe(
      tap((res) => {
        this.numberOfCartItems.set(res.numOfCartItems);
      }),
    );
  }

  clearCart(): Observable<any> {
    return this.httpClient.delete<any>(`${environment.baseURL}/api/v1/cart`).pipe(
      tap(() => {
        this.numberOfCartItems.set(0);
      }),
    );
  }

  updateItemQTY(itemId: string, itemCount: number): Observable<any> {
    return this.httpClient
      .put<any>(`${environment.baseURL}/api/v1/cart/${itemId}`, {
        count: itemCount,
      })
      .pipe(
        tap((res) => {
          this.numberOfCartItems.set(res.numOfCartItems);
        }),
      );
  }

  checkoutSession(cartId: string, data: any): Observable<any> {
    const origin = isPlatformBrowser(this.platformId) ? window.location.origin : '';

    return this.httpClient.post<any>(
      `${environment.baseURL}/api/v1/orders/checkout-session/${cartId}?url=${origin}`,
      { shippingAddress: data },
    );
  }

  createCashOrder(cartId: string, data: any): Observable<any> {
    return this.httpClient.post<any>(`${environment.baseURL}/api/v1/orders/${cartId}`, {
      shippingAddress: data,
    });
  }
}
