import { HttpClient } from '@angular/common/http';
import { inject, Injectable, PLATFORM_ID, signal, computed } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../../environments/environment.development';
import { isPlatformBrowser } from '@angular/common';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly platformId = inject(PLATFORM_ID);
  private readonly router = inject(Router);

  // استخدام Signal بدلاً من BehaviorSubject للتحكم في الحالة بشكل تفاعلي حديث
  currentUserSignal = signal<boolean>(this.checkInitialLogin());

  // خاصية مشتقة (Computed) تعطي حالة تسجيل الدخول مباشرة
  isLoggedIn = computed(() => this.currentUserSignal());

  private checkInitialLogin(): boolean {
    if (isPlatformBrowser(this.platformId)) {
      return !!localStorage.getItem('token');
    }
    return false;
  }

  signUp(data: any): Observable<any> {
    return this.http.post(`${environment.baseURL}/api/v1/auth/signup`, data);
  }

  signIn(data: any): Observable<any> {
    return this.http.post<any>(`${environment.baseURL}/api/v1/auth/signin`, data).pipe(
      tap((res) => {
        if (res.token && isPlatformBrowser(this.platformId)) {
          localStorage.setItem('token', res.token);
          this.currentUserSignal.set(true);
        }
      }),
    );
  }

  forgotPassword(data: any): Observable<any> {
    return this.http.post(`${environment.baseURL}/api/v1/auth/forgotPasswords`, data);
  }

  verifyResetCode(data: any): Observable<any> {
    return this.http.post(`${environment.baseURL}/api/v1/auth/verifyResetCode`, data);
  }

  resetPassword(data: any): Observable<any> {
    return this.http.put(`${environment.baseURL}/api/v1/auth/resetPassword`, data);
  }

  getToken(): string | null {
    if (isPlatformBrowser(this.platformId)) {
      return localStorage.getItem('token');
    }
    return null;
  }

  updateLoginStatus() {
    this.currentUserSignal.set(this.checkInitialLogin());
  }

  logout() {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('token');
      this.currentUserSignal.set(false);
      this.router.navigate(['/login']);
    }
  }
}
